using UiPath.CodedWorkflows;

namespace GenerateEmployeeID_ProjectFile
{
    public partial class CodedWorkflow : CodedWorkflowBase
    {
        public CodedWorkflow()
        {
            _ = new System.Type[]{};
        }
    }
}